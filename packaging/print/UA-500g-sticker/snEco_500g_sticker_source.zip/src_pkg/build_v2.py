# -*- coding: utf-8 -*-
import sys, os; sys.path.insert(0, '/home/claude/work')
from layout_v2 import *
import post_v2

def comp_ol(st, x, y, w):
    st.text(x, y, 'СКЛАД:', 'black', MAND+0.6, YELLOW)
    st.text(x+st.tw('СКЛАД: ', 'black', MAND+0.6), y, 'оливки, сіль кухонна.', 'reg', MAND, WHITE)
    return y

OL = dict(
    key='OL',
    badges=['OL_keto', 'OL_vegan', 'OL2_patented', 'OL2_renew', 'OL2_made'],
    hero='OL_hero', hero_x=-2.0, hero_y=14.0, hero_w=57.0,
    rx=58.0, logo_w=52.0,
    title='OL_title', title_y=31.5, title_w=74.0,
    sub='OL_sub', sub_y=47.0, sub_w=62.0,
    side='OL_100nat', side_y=47.0, side_h=15.0,
    claim='БЕЗ РОЗСОЛУ. БЕЗ ОЛІЇ. ТІЛЬКИ ОЛИВКИ, ЯКІ МОЖНА ЇСТИ РУКАМИ.',
    chips=['НЕ ПОТРЕБУЄ ХОЛОДИЛЬНИКА', 'ЗБЕРІГАЄТЬСЯ 12 МІСЯЦІВ',
           'ГОТОВИЙ ДО ВЖИВАННЯ', 'ДО ВИНА, САЛАТІВ І ТАПАСІВ'],
    dot=GREEN,
    rows=[('ЕНЕРГЕТИЧНА\nЦІННІСТЬ', '2900 кДж\n693 ккал', '725 кДж\n173 ккал'),
          ('ЖИРИ', '60,1 г', '15,0 г'),
          ('З НИХ НАСИЧЕНІ', '11,6 г', '2,9 г'),
          ('ВУГЛЕВОДИ', '23,1 г', '5,8 г'),
          ('З НИХ ЦУКРИ', '0 г', '0 г'),
          ('КЛІТКОВИНА', '16,2 г', '4,1 г'),
          ('БІЛКИ', '5,8 г', '1,5 г'),
          ('СІЛЬ', '8,4 г', '2,1 г')],
    composition=comp_ol, ean=None,
    out='/home/claude/work/out2/snEco_OLIVES_500g_sticker_150x150',
    meta='snEco Хрусткі оливки 500 г — стікер 150×150 мм',
)

def comp_br(st, x, y, w):
    st.text(x, y, 'СКЛАД:', 'black', MAND+0.6, YELLOW)
    x0 = x+st.tw('СКЛАД: ', 'black', MAND+0.6)
    st.text(x0, y, 'сир (', 'reg', MAND, WHITE)
    x1 = x0+st.tw('сир (', 'reg', MAND)
    al = 'молоко коров’яче'
    st.text(x1, y, al, 'bold', MAND, WHITE)
    st.line(x1, y+0.9, x1+st.tw(al, 'bold', MAND), y+0.9, col=WHITE, w=0.25)
    st.text(x1+st.tw(al, 'bold', MAND), y, ',', 'reg', MAND, WHITE)
    st.para(x, y+BASE, '', 'reg', MAND, WHITE, w, lead=BASE,
            lines=['сіль кухонна, культури молочнокислих бактерій,',
                   'культура плісняви Penicillium roqueforti).'])
    return y+2*BASE

BR = dict(
    key='BR',
    badges=['OL_keto', 'OL_cosmic', 'OL2_patented', 'OL2_renew', 'OL2_made'],
    hero='BR_hero', hero_x=-3.0, hero_y=16.0, hero_w=62.0,
    rx=58.0, logo_w=52.0,
    title='BR_title', title_y=32.0, title_w=72.0,
    sub='BR_sub', sub_y=44.6, sub_w=58.0,
    side='BR_ticket', side_y=44.5, side_h=17.5,
    claim='СПРАВЖНІЙ BLUE ROYALE, ЯКИЙ ХРУСТИТЬ. 31,7 г БІЛКА НА 100 г.',
    chips=['НЕ ПОТРЕБУЄ ХОЛОДИЛЬНИКА', '100% СИР', 'ГОТОВИЙ ДО ВЖИВАННЯ',
           'ДО ВИНА, САЛАТІВ, СУПІВ І ПАСТИ'],
    dot=KRAFT,
    rows=[('ЕНЕРГЕТИЧНА\nЦІННІСТЬ', '2465 кДж\n589 ккал', '616 кДж\n147 ккал'),
          ('ЖИРИ', '51 г', '12,8 г'),
          ('З НИХ НАСИЧЕНІ', '33 г', '8,3 г'),
          ('ВУГЛЕВОДИ', '1 г', '0,3 г'),
          ('З НИХ ЦУКРИ', '1 г', '0,3 г'),
          ('БІЛКИ', '31,7 г', '7,9 г'),
          ('СІЛЬ', '6,2 г', '1,6 г')],
    composition=comp_br, ean='4823095818000',
    out='/home/claude/work/out2/snEco_BLUE_ROYALE_500g_sticker_150x150',
    meta='snEco Blue Royale 500 г — стікер 150×150 мм',
)

os.makedirs('/home/claude/work/out2', exist_ok=True)
for cfg in (OL, BR):
    # ---- flat print file ----
    st = build(cfg)
    raw = cfg['out']+'_raw.pdf'
    st.doc.save(raw, garbage=4, deflate=True)
    post_v2.finish(raw, cfg['out']+'_PRINT.pdf', cfg['meta'])

    # ---- layered edit file ----
    layers = []
    for label, z in ZONES:
        s2 = build(cfg, zones=(z,))
        p = cfg['out']+f'_L_{z}.pdf'
        s2.doc.save(p, garbage=4, deflate=True)
        layers.append((label, p))
    master = pymupdf.open()
    mp = master.new_page(width=PAGE*MM, height=PAGE*MM)
    for label, p in layers:
        ocg = master.add_ocg(label, on=True)
        src = pymupdf.open(p)
        mp.show_pdf_page(mp.rect, src, 0, oc=ocg)
    lraw = cfg['out']+'_layers_raw.pdf'
    master.save(lraw, garbage=4, deflate=True)
    post_v2.finish(lraw, cfg['out']+'_EDIT.pdf', cfg['meta']+' (шари)')
    for label, p in layers: os.remove(p)
    os.remove(raw); os.remove(lraw)
    print('ok', cfg['key'])
