# -*- coding: utf-8 -*-
import sys; sys.path.insert(0, '/home/claude/work')
from sticker_v2 import *

M0, M1 = 6.0, 144.0
LIVE = M1-M0
CA, CB = 6.0, 76.5
CW = 67.5

STORAGE = ('Масова частка жиру в сухій речовині не менше 20%. Номер партії вказано на упаковці. '
           'Зберігати у темному місці при температурі від 0º до 30ºС та відносній вологості '
           'повітря не більше 70%. Відкриту пачку зберігати не більше 2 діб.')
TU = 'Виготовлено згідно ТУ У 10.5-40271201-001 : 2016'
PRODUCER = ['ТОВ «Прайм Снек», Україна, 89600,',
            'м. Мукачево, вул. Берегівська-бічна, 15 —',
            'юридична адреса та потужності виробництва.',
            'Експлуатаційний дозвіл № a-UA-21-04-01-IX-PP',
            'Тел.: +380 97 307 9354   ·   sales@sneco.ua']

BADGE_K = {'OL_keto': 0.92, 'OL_vegan': 1.0, 'OL_cosmic': 0.92,
           'OL2_patented': 1.0, 'OL2_renew': 1.0, 'OL2_made': 1.0}


def nutrition(st, x, y, w, rows, portion='25 г', hdr=7.0, r1=3.95):
    c0, c1 = w*0.40, w*0.70
    st.rect(x, y, x+w, y+hdr, fill=YELLOW)
    st.para(x+1.6, y+3.2, '', 'black', MAND_CAPS-0.6, BLACK, c0-3, lead=2.9,
            lines=['ПОЖИВНА', 'ЦІННІСТЬ'])
    m1, m2 = x+(c0+c1)/2-0.4, x+(c1+w)/2-0.4
    st.text(m1, y+3.2, 'на', 'bold', MKT-0.4, BLACK, 'c')
    st.text(m1, y+6.2, '100 г', 'black', MAND, BLACK, 'c')
    st.text(m2, y+3.2, 'на порцію', 'bold', MKT-0.4, BLACK, 'c')
    st.text(m2, y+6.2, portion, 'black', MAND, BLACK, 'c')
    cy = y+hdr
    for name, a, b in rows:
        nl, al = name.split('\n'), a.split('\n')
        h = r1*len(al)
        st.para(x+1.6, cy+(2.85 if len(nl) == 1 else 2.6), '', 'semi', MAND_CAPS, WHITE,
                c0-3, lead=BASE, lines=nl)
        for txt, cl, cr in ((a, c0, c1), (b, c1, w)):
            for k, t in enumerate(txt.split('\n')):
                num, _, unit = t.rpartition(' ')
                ux = x+(cl+cr)/2+1.0
                yy = cy+(2.85 if len(al) == 1 else 2.6)+k*r1
                st.text(ux, yy, unit, 'reg', MAND, WHITE)
                st.text(ux-1.1, yy, num, 'reg', MAND, WHITE, 'r')
        cy += h
        st.line(x, cy, x+w, cy, col=YELLOW, w=0.30)
    st.line(x, y+hdr, x, cy, col=YELLOW, w=0.30)
    st.line(x+w, y+hdr, x+w, cy, col=YELLOW, w=0.30)
    return cy


# ---------------------------------------------------------------- zones
def z_face(st, cfg):
    n = len(cfg['badges']); slot = LIVE/n
    for i, b in enumerate(cfg['badges']):
        h = 7.8*BADGE_K.get(b, 1.0)
        st.art(b, M0+slot*(i+0.5), 12.4-h, h=h, anchor='tc')

    st.art(cfg['hero'], cfg['hero_x'], cfg['hero_y'], w=cfg['hero_w'])
    st.art('OL_zigzag', -3, 13.2, w=156)

    RX = cfg['rx']
    st.art('OL_logo', RX, 16.0, w=cfg['logo_w'])
    st.art(cfg['title'], RX, cfg['title_y'], w=cfg['title_w'])
    st.art(cfg['sub'], RX, cfg['sub_y'], w=cfg['sub_w'])

    tx0, ty0, tx1, ty1 = RX, 50.6, RX+58.0, 62.0
    stamp(st, tx0, ty0, tx1, ty1, fill=YELLOW)
    st.text(tx0+4.5, ty0+4.2, 'МАСА НЕТТО', 'black', 6.0, BLACK, tracking=0.3)
    st.text(tx0+4.5, ty0+10.6, '500 г', 'heavy', 13.5, BLACK)
    st.line(tx0+30.5, ty0+2.2, tx0+30.5, ty1-2.2, col=BLACK, w=0.35)
    st.text(tx0+33.5, ty0+5.4, '= 20 ПОРЦІЙ', 'black', 7.2, BLACK)
    st.text(tx0+33.5, ty0+10.0, 'ПО 25 г', 'black', 7.2, BLACK)

    st.art(cfg['side'], M1, cfg['side_y'], h=cfg['side_h'], anchor='tr')
    st.line(M0, 63.6, M1, 63.6, col=YELLOW, w=0.5)


def z_claim(st, cfg):
    sz = st.fit(cfg['claim'], 'black', MKT_BIG, LIVE)
    st.text(M0, 69.2, cfg['claim'], 'black', sz, WHITE)
    csz = MKT
    while sum(st.tw(c, 'semi', csz) for c in cfg['chips'])+4.4*(len(cfg['chips'])-1) > LIVE:
        csz -= 0.1
    cx = M0
    for i, chip in enumerate(cfg['chips']):
        if i:
            st.page.draw_circle(pymupdf.Point(X(cx+1.4), Y(74.0)), 0.55*MM, color=None, fill=cfg['dot'])
            cx += 4.4
        cx += st.text(cx, 74.6, chip, 'semi', csz, WHITE)
    st.line(M0, 77.2, M1, 77.2, col=W40, w=0.3)


def z_info(st, cfg):
    nutrition(st, CA, 79.6, CW, cfg['rows'])
    cy = 82.6
    cy = cfg['composition'](st, CB, cy, CW) + BASE+1.4
    st.text(CB, cy, 'МАСА НЕТТО:', 'black', MAND+0.6, YELLOW)
    st.text(CB+st.tw('МАСА НЕТТО: ', 'black', MAND+0.6), cy, '500 г', 'bold', MAND+0.6, WHITE)
    st.text(CB+st.tw('МАСА НЕТТО: 500 г   ', 'black', MAND+0.6), cy,
            '(≈20 порцій по 25 г)', 'reg', MAND, WHITE)
    cy += BASE+1.4
    cy = st.para(CB, cy, STORAGE, 'reg', MAND, WHITE, CW, lead=BASE)+BASE+1.4
    st.para(CB, cy, TU, 'semi', MAND, WHITE, CW, lead=BASE)


def z_band(st, cfg):
    B = 123.0
    st.line(M0, B, M1, B, col=W40, w=0.3)

    st.text(M0, B+4.2, 'КРАЩЕ СПОЖИТИ ДО', 'semi', MICRO, WHITE)
    st.rect(M0, B+5.0, M0+28, B+11.6, fill=WHITE)
    st.text(M0, B+16.2, 'НОМЕР ПАРТІЇ', 'semi', MICRO, WHITE)
    st.rect(M0, B+17.0, M0+28, B+23.0, fill=WHITE)

    st.art('OL2_qr', 37.0, B+1.0, h=13.0)
    st.text(37.0, B+17.4, 'SNECO.UA', 'black', MICRO, YELLOW)
    st.art('OL2_recycle', 37.0, B+18.4, h=5.8)
    st.art('OL2_fork', 44.0, B+18.6, h=5.4)

    if cfg.get('ean'):
        draw_ean13(st, cfg['ean'], 53.0, B+1.0)
    else:
        st.rect(53.0, B+1.0, 53.0+29.83, B+1.0+22.88, fill=WHITE)
        st.para(53.8, B+9.6, '', 'semi', MICRO, (0, 0, 0, 0.6), 28.2, lead=2.9, align='c',
                lines=['МІСЦЕ ПІД EAN-13', '30 × 23 мм, X = 0,264 мм', 'код 500 г', 'ще не присвоєно'])

    PX, PW = 86.0, 58.0
    st.text(PX, B+4.2, 'ВИРОБНИК:', 'black', MAND, YELLOW)
    st.para(PX+st.tw('ВИРОБНИК: ', 'black', MAND), B+4.2, '', 'reg', MAND, WHITE, PW,
            lead=BASE, lines=[PRODUCER[0]])
    st.para(PX, B+4.2+BASE, '', 'reg', MAND, WHITE, PW, lead=BASE, lines=PRODUCER[1:])


ZONES = [('1 Фон', 'bg'), ('2 Лицьовий блок', 'face'),
         ('3 Клейм-стрічка', 'claim'), ('4 Інформація', 'info'),
         ('5 Штрихкод / дата / виробник', 'band')]
FN = {'face': z_face, 'claim': z_claim, 'info': z_info, 'band': z_band}


def build(cfg, zones=('bg', 'face', 'claim', 'info', 'band')):
    st = Sticker(bg=('bg' in zones))
    for z in ('face', 'claim', 'info', 'band'):
        if z in zones:
            FN[z](st, cfg)
    return st
