# -*- coding: utf-8 -*-
"""post-processing: global black remap (TAC 279% -> 240%), CutContour die-line, boxes, metadata"""
import re, pikepdf
from pikepdf import Name, Dictionary, Array, String

MM = 72/25.4
BLEED, TRIM = 3.0, 150.0
PAGE = TRIM+2*BLEED
OFF = BLEED*MM
OLD = (0.72, 0.62, 0.60, 0.85)
NEW = (0.60, 0.40, 0.40, 1.00)
TOL = 0.005

_num = r'(?<![\d.])(\d*\.?\d+)'
_pat = re.compile((_num+r'\s+')*3 + _num + r'\s+(k|K)')

def _remap(data: bytes) -> bytes:
    def sub(m):
        v = [float(m.group(i)) for i in range(1, 5)]
        if all(abs(v[i]-OLD[i]) < TOL for i in range(4)):
            return ('%g %g %g %g ' % NEW)+m.group(5)
        return m.group(0)
    try:
        s = data.decode('latin-1')
    except Exception:
        return data
    return _pat.sub(sub, s).encode('latin-1')


def finish(src, dst, title):
    pdf = pikepdf.open(src)
    page = pdf.pages[0]

    # ---- 1. remap the rich black in EVERY form XObject + page contents ----
    targets = []
    for obj in pdf.objects:
        try:
            if isinstance(obj, pikepdf.Stream) and obj.get('/Subtype') == Name('/Form'):
                targets.append(obj)
        except Exception:
            pass
    for obj in targets:
        try:
            data = obj.read_bytes()
            new_data = _remap(data)
            if new_data != data:
                obj.write(new_data)
        except Exception:
            pass
    page.contents_coalesce()
    page.Contents.write(_remap(page.Contents.read_bytes()))

    # ---- 2. CutContour die-line: Separation spot, own OCG layer, overprinting ----
    tint = pdf.make_stream(b'{dup 0 mul exch dup 1 mul exch dup 1 mul exch 0 mul}')
    tint.stream_dict = Dictionary(FunctionType=4, Domain=Array([0, 1]),
                                  Range=Array([0, 1, 0, 1, 0, 1, 0, 1]))
    sep = pdf.make_indirect(Array([Name('/Separation'), Name('/CutContour'),
                                   Name('/DeviceCMYK'), tint]))
    ocg = pdf.make_indirect(Dictionary(Type=Name('/OCG'), Name=String('Die-line (CutContour)')))
    if '/OCProperties' in pdf.Root:
        ocp = pdf.Root['/OCProperties']
        ocp['/OCGs'].append(ocg)
        d = ocp['/D']
        if '/Order' in d: d['/Order'].append(ocg)
        else: d[Name('/Order')] = Array([ocg])
        if '/ON' in d: d['/ON'].append(ocg)
        else: d[Name('/ON')] = Array([ocg])
    else:
        pdf.Root[Name('/OCProperties')] = Dictionary(
            OCGs=Array([ocg]),
            D=Dictionary(Order=Array([ocg]), ON=Array([ocg]), BaseState=Name('/ON')))
    gs = pdf.make_indirect(Dictionary(Type=Name('/ExtGState'), OP=True, op=True, OPM=1))

    r = 5.0*MM                                   # 5 mm corner radius
    x0, y0 = OFF, OFF
    x1, y1 = OFF+TRIM*MM, OFF+TRIM*MM
    k = 0.5523*r
    p = (f"{x0+r:.3f} {y0:.3f} m {x1-r:.3f} {y0:.3f} l "
         f"{x1-r+k:.3f} {y0:.3f} {x1:.3f} {y0+r-k:.3f} {x1:.3f} {y0+r:.3f} c "
         f"{x1:.3f} {y1-r:.3f} l "
         f"{x1:.3f} {y1-r+k:.3f} {x1-r+k:.3f} {y1:.3f} {x1-r:.3f} {y1:.3f} c "
         f"{x0+r:.3f} {y1:.3f} l "
         f"{x0+r-k:.3f} {y1:.3f} {x0:.3f} {y1-r+k:.3f} {x0:.3f} {y1-r:.3f} c "
         f"{x0:.3f} {y0+r:.3f} l "
         f"{x0:.3f} {y0+r-k:.3f} {x0+r-k:.3f} {y0:.3f} {x0+r:.3f} {y0:.3f} c h ")
    content = (b"q /OC /DieOC BDC /GSdie gs /CSdie CS 1 SCN 0.75 w "
               + p.encode() + b"S EMC Q")
    die = pdf.make_stream(content)
    page.Contents = Array([page.Contents, die])

    pres = page['/Resources']
    if '/ColorSpace' not in pres: pres[Name('/ColorSpace')] = Dictionary()
    pres['/ColorSpace'][Name('/CSdie')] = sep
    if '/ExtGState' not in pres: pres[Name('/ExtGState')] = Dictionary()
    pres['/ExtGState'][Name('/GSdie')] = gs
    if '/Properties' not in pres: pres[Name('/Properties')] = Dictionary()
    pres['/Properties'][Name('/DieOC')] = ocg

    # ---- 3. boxes ----
    page.MediaBox = Array([0, 0, PAGE*MM, PAGE*MM])
    page.BleedBox = Array([0, 0, PAGE*MM, PAGE*MM])
    page.TrimBox = Array([OFF, OFF, OFF+TRIM*MM, OFF+TRIM*MM])
    if '/ArtBox' in page: del page['/ArtBox']

    with pdf.open_metadata() as meta:
        meta['dc:title'] = title
        meta['dc:description'] = ('150×150 mm sticker, trim 150×150, bleed 3 mm, '
                                  'die-line on CutContour spot (R5), device CMYK, TAC 240%')
        meta['pdf:Producer'] = 'snEco'
    pdf.save(dst, linearize=False, compress_streams=True, object_stream_mode=pikepdf.ObjectStreamMode.generate)
    pdf.close()
