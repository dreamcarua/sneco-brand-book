# -*- coding: utf-8 -*-
"""snEco 500 g sticker 150x150 mm — v2 (after prepress / marketing / typography review)"""
import pymupdf, json, math

MM = 72/25.4
BLEED, TRIM = 3.0, 150.0
PAGE = TRIM + 2*BLEED
OFF = BLEED*MM

# ---- colours (CMYK) ----
BLACK  = (0.60, 0.40, 0.40, 1.00)     # TAC 240% (was 72/62/60/85 = 279%)
BLACK_SRC = (0.72, 0.62, 0.60, 0.85)  # black used inside the imported artwork
YELLOW = (0.00, 0.27, 0.94, 0.00)
GREEN  = (0.427, 0.033, 1.00, 0.00)
KRAFT  = (0.25, 0.40, 0.65, 0.00)
WHITE  = (0.00, 0.00, 0.00, 0.00)
K100   = (0.00, 0.00, 0.00, 1.00)
W40    = (0.00, 0.00, 0.00, 0.55)

# ---- type roles (Qanelas: x-height 0.50 em, cap-height 0.70 em) ----
MAND      = 7.0    # mandatory text  -> x-height 1.235 mm  (legal floor 1.2)
MAND_CAPS = 7.0
MKT_BIG   = 8.6
MKT       = 6.6
MICRO     = 5.6
BASE      = 3.5    # baseline step for legal text

SRC = {'OL':'/root/.claude/uploads/c24a0bf9-0e1a-5daa-80cc-52c8ddd9268d/cd11235c-SNECO_OLIVES_100x200_F.pdf',
       'BR':'/root/.claude/uploads/c24a0bf9-0e1a-5daa-80cc-52c8ddd9268d/43199aee-SNECO_BR_100x200_F.pdf'}
DOCS = {k: pymupdf.open(v) for k, v in SRC.items()}
REG  = json.load(open('/home/claude/work/regions.json'))

FONTS = {'light':'Qanelas-Light','reg':'Qanelas-Regular','med':'Qanelas-Medium',
         'semi':'Qanelas-SemiBold','bold':'Qanelas-Bold','xbold':'Qanelas-ExtraBold',
         'black':'Qanelas-Black','heavy':'Qanelas-Heavy','hv':'HighVoltage Rough'}
FONTS = {k: f'/home/claude/work/fonts/{v}.ttf' for k, v in FONTS.items()}
MET = {k: pymupdf.Font(fontfile=v) for k, v in FONTS.items()}

def X(v): return OFF + v*MM
def Y(v): return OFF + v*MM
def R(x0, y0, x1, y1): return pymupdf.Rect(X(x0), Y(y0), X(x1), Y(y1))

_RC = {}
def region(key):
    if key in _RC: return _RC[key]
    tag, pno, r = REG[key]
    t = pymupdf.open()
    p = t.new_page(width=r[2]-r[0], height=r[3]-r[1])
    p.show_pdf_page(p.rect, DOCS[tag], pno-1, clip=pymupdf.Rect(*r))
    _RC[key] = t
    return t


class Sticker:
    def __init__(self, bg=True):
        self.doc = pymupdf.open()
        self.page = self.doc.new_page(width=PAGE*MM, height=PAGE*MM)
        for k, v in FONTS.items():
            self.page.insert_font(fontname=k, fontfile=v)
        if bg:
            self.page.draw_rect(pymupdf.Rect(0, 0, PAGE*MM, PAGE*MM), color=None, fill=BLACK)

    # ---------- text ----------
    def tw(self, s, f, sz): return MET[f].text_length(s, fontsize=sz)/MM

    def text(self, x, y, s, f='reg', sz=7, col=WHITE, align='l', tracking=0):
        w = self.tw(s, f, sz) + tracking*max(0, len(s)-1)/MM
        if align == 'c': x -= w/2
        elif align == 'r': x -= w
        if tracking:
            cx = x
            for ch in s:
                self.page.insert_text((X(cx), Y(y)), ch, fontname=f, fontsize=sz, color=col)
                cx += self.tw(ch, f, sz) + tracking/MM
        else:
            self.page.insert_text((X(x), Y(y)), s, fontname=f, fontsize=sz, color=col)
        return w

    def fit(self, s, f, sz, width):
        """shrink size until the string fits width"""
        while sz > 4.0 and self.tw(s, f, sz) > width:
            sz -= 0.1
        return sz

    def wrap(self, s, f, sz, width):
        out, cur = [], ''
        for w in s.split(' '):
            t = (cur+' '+w).strip()
            if self.tw(t, f, sz) <= width or not cur: cur = t
            else: out.append(cur); cur = w
        if cur: out.append(cur)
        return out

    def para(self, x, y, s, f='reg', sz=MAND, col=WHITE, width=60, lead=BASE,
             align='l', lines=None):
        ls = lines if lines is not None else self.wrap(s, f, sz, width)
        cy = y
        for ln in ls:
            ax = x if align == 'l' else (x+width/2 if align == 'c' else x+width)
            self.text(ax, cy, ln, f, sz, col, align)
            cy += lead
        return cy - lead

    # ---------- shapes ----------
    def rect(self, x0, y0, x1, y1, fill=None, col=None, w=0.25):
        self.page.draw_rect(R(x0, y0, x1, y1), color=col, fill=fill, width=w*MM)

    def line(self, x0, y0, x1, y1, col=WHITE, w=0.3):
        self.page.draw_line(pymupdf.Point(X(x0), Y(y0)), pymupdf.Point(X(x1), Y(y1)),
                            color=col, width=w*MM)

    # ---------- imported artwork ----------
    def asize(self, key):
        _, _, r = REG[key]
        return (r[2]-r[0])/MM, (r[3]-r[1])/MM

    def art(self, key, x, y, w=None, h=None, anchor='tl'):
        _, _, r = REG[key]
        ar = (r[2]-r[0])/(r[3]-r[1])
        if w is None and h is None: w = (r[2]-r[0])/MM
        if w is None: w = h*ar
        if h is None: h = w/ar
        if anchor == 'tc': x -= w/2
        elif anchor == 'tr': x -= w
        self.page.show_pdf_page(R(x, y, x+w, y+h), region(key), 0)
        return w, h


# ---------------- stamp / ticket ----------------
def stamp(st, x0, y0, x1, y1, fill=YELLOW, notch=1.15, bg=BLACK):
    st.rect(x0, y0, x1, y1, fill=fill)
    def dots(p0, p1, fixed, horiz):
        n = max(3, int(round((p1-p0)/(notch*1.6)))); step = (p1-p0)/n
        for i in range(n+1):
            c = p0+i*step
            pt = pymupdf.Point(X(c), Y(fixed)) if horiz else pymupdf.Point(X(fixed), Y(c))
            st.page.draw_circle(pt, notch/2*MM, color=None, fill=bg)
    dots(x0, x1, y0, True); dots(x0, x1, y1, True)
    dots(y0, y1, x0, False); dots(y0, y1, x1, False)


# ---------------- EAN-13 ----------------
_L = ['0001101','0011001','0010011','0111101','0100011','0110001','0101111','0111011','0110111','0001011']
_G = ['0100111','0110011','0011011','0100001','0011101','0111001','0000101','0010001','0001001','0010111']
_R = ['1110010','1100110','1101100','1000010','1011100','1001110','1010000','1000100','1001000','1110100']
_P = ['LLLLLL','LLGLGG','LLGGLG','LLGGGL','LGLLGG','LGGLLG','LGGGLL','LGLGLG','LGLGGL','LGGLGL']

def ean13_modules(code):
    d = [int(c) for c in code]
    out = '101'
    for i, p in enumerate(_P[d[0]]):
        out += (_L if p == 'L' else _G)[d[1+i]]
    out += '01010'
    for i in range(6):
        out += _R[d[7+i]]
    return out+'101'

def ean13_check(d12):
    return str((10-sum(int(c)*(3 if i % 2 else 1) for i, c in enumerate(d12)) % 10) % 10)

def draw_ean13(st, code, x, y, mag=0.80):
    """GS1-conformant: X = 0.33*mag, full (untruncated) bar height, 11/7-module quiet zones."""
    assert len(code) == 13 and ean13_check(code[:12]) == code[12], 'bad EAN-13'
    m = 0.33*mag
    bar_h = 22.85*mag                 # full nominal bar height (no truncation)
    qz_l, qz_r = 11*m, 7*m
    pw = qz_l + 95*m + qz_r
    ph = bar_h + 1.2 + 3.4
    st.rect(x, y, x+pw, y+ph, fill=WHITE)
    x0 = x+qz_l
    guard = set(list(range(0, 3))+list(range(45, 50))+list(range(92, 95)))
    mods = ean13_modules(code)
    i = 0
    while i < len(mods):
        if mods[i] == '1':
            j = i
            while j+1 < len(mods) and mods[j+1] == '1' and ((j+1) in guard) == (i in guard):
                j += 1
            h = bar_h if i in guard else bar_h-5*m
            st.rect(x0+i*m, y+1.2, x0+(j+1)*m, y+1.2+h, fill=K100)
            i = j+1
        else:
            i += 1
    base = y+1.2+bar_h+2.4
    sz = 7.2*mag/0.8
    st.text(x+0.8, base, code[0], 'reg', sz, K100)
    st.text(x0+24*m, base, code[1:7], 'reg', sz, K100, 'c')
    st.text(x0+71*m, base, code[7:], 'reg', sz, K100, 'c')
    return pw, ph
